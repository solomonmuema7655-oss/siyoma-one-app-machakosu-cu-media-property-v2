# SIYOMA ONE APP-MACHAKOS UNIVERSITY CU MEDIA PROPERTY V2
Local-first CU media preparation and live projection foundation.

V2 includes functional navigation, service queue, projection controls, blank/holding screen,
automatic date/footer, text/lyrics block handling, local media pickers, songs/audio,
Today's Service Program, Settings, and a provider-ready Bible module.

Copyright © 2026 SiyomaCodingPrograms
