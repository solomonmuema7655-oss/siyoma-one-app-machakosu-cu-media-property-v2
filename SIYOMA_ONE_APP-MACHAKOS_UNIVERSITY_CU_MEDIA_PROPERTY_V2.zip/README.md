# SIYOMA ONE APP-MACHAKOS UNIVERSITY CU MEDIA PROPERTY V2

Phone-friendly local/private CU media control and projection application.

This V2 upgrade fixes the V2 build without creating V3:
- Android WebView file chooser support for local audio/video/image files.
- Official SIYOMA ONE CU Media launcher icon.
- SIYOMA PASSWORD (239358) is required only on first installation/setup; subsequent app openings do not ask for it again.
- Projection state is preserved when returning to the control screen; Live Projection can be reopened without losing the current item.
- Explicit Back, Home, Blank, Holding, Next, Previous and Clear Projection controls.
- Today's date and configurable copyright footer remain part of projection.

Build locally/private through the included GitHub Actions workflow. This is a debug APK workflow; no Play Store/AAB release is included.
