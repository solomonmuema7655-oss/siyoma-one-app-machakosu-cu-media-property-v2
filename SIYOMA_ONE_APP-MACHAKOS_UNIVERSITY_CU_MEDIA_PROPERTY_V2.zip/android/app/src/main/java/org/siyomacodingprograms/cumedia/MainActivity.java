package org.siyomacodingprograms.cumedia;

import android.app.Activity;
import android.app.Presentation;
import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.view.Display;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowManager;
import android.graphics.Color;

public class MainActivity extends Activity {
    private WebView w;
    private ProjectionPresentation presentation;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        w = new WebView(this);
        w.setWebViewClient(new WebViewClient());
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView, android.webkit.ValueCallback<android.net.Uri[]> callback, FileChooserParams params) {
                return FileChooser.open(MainActivity.this, callback, params);
            }
        });
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        w.addJavascriptInterface(new ProjectionBridge(), "AndroidProjection");
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }

    private DisplayManager dm() { return (DisplayManager)getSystemService(Context.DISPLAY_SERVICE); }

    private Display getPresentationDisplay() {
        Display[] displays = dm().getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        return displays.length > 0 ? displays[0] : null;
    }

    private class ProjectionBridge {
        @JavascriptInterface public boolean hasExternalDisplay() { return getPresentationDisplay() != null; }
        @JavascriptInterface public void showProjection(final String html) {
            runOnUiThread(() -> {
                Display d = getPresentationDisplay();
                if (d == null) return;
                if (presentation != null) presentation.dismiss();
                presentation = new ProjectionPresentation(MainActivity.this, d, html);
                presentation.show();
            });
        }
        @JavascriptInterface public void clearProjection() {
            runOnUiThread(() -> { if (presentation != null) { presentation.dismiss(); presentation = null; } });
        }
    }

    public static class ProjectionPresentation extends Presentation {
        private final String html;
        ProjectionPresentation(Context context, Display display, String html) { super(context, display); this.html = html; }
        @Override protected void onCreate(Bundle b) {
            super.onCreate(b);
            WebView view = new WebView(getContext());
            view.setBackgroundColor(Color.BLACK);
            WebSettings s = view.getSettings();
            s.setJavaScriptEnabled(false);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(true);
            s.setAllowContentAccess(true);
            view.setLayoutParams(new ViewGroup.LayoutParams(-1,-1));
            view.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            setContentView(view);
        }
    }

    private static class FileChooser {
        private static android.webkit.ValueCallback<android.net.Uri[]> callback;
        static boolean open(Activity a, android.webkit.ValueCallback<android.net.Uri[]> cb, WebChromeClient.FileChooserParams params) {
            if (callback != null) callback.onReceiveValue(null);
            callback = cb;
            try { a.startActivityForResult(params.createIntent(), 9001); return true; }
            catch (Exception e) { callback = null; cb.onReceiveValue(null); return false; }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 9001 || FileChooser.callback == null) return;
        android.net.Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount(); results = new android.net.Uri[n];
                for (int i=0;i<n;i++) results[i]=data.getClipData().getItemAt(i).getUri();
            } else if (data.getData()!=null) results = new android.net.Uri[]{data.getData()};
        }
        FileChooser.callback.onReceiveValue(results); FileChooser.callback=null;
    }

    @Override public void onBackPressed() { w.evaluateJavascript("window.C&&window.C.back()", null); }
    @Override protected void onDestroy() { if (presentation != null) presentation.dismiss(); super.onDestroy(); }
}
